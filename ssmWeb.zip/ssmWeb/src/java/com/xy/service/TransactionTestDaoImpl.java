package com.xy.service;

import com.xy.dao.TransactionTestDao;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;

@Repository
public class TransactionTestDaoImpl extends SqlSessionDaoSupport implements TransactionTestDao {

   // 1，重写父类 【SqlSessionDaoSupport】方法实现注入【sqlSessionFactory】。
   // 2，必须要有，在配置文件【applicationContext.xml】要配置过。
   @Resource
   public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory){
      super.setSqlSessionFactory(sqlSessionFactory);
   }

   /**
    * 转入操作
    * @param userId    装入账号
    * @param money     交易金额
    */
   @Override
   public void increaseMoney(@Param("userId") String userId, @Param("moneyNm") Long moneyNm) {
      TransactionTestDao mapper = super.getSqlSession().getMapper(TransactionTestDao.class);
      mapper.increaseMoney(userId, moneyNm);
   }
}