package com.xy.service;

import com.xy.dao.MysqlTransactionTestDao;
import com.xy.dao.TransactionTestDao;
import com.xy.daodev.TransactionTestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;

@Service
public class TransactionTestServiceImpl implements TransactionTestService {
   @Autowired
	@Qualifier("mysqlTransactionTestDao")
	private MysqlTransactionTestDao mysqlTransactionTestDao;
	
	@Autowired
	@Qualifier("transactionTestDao")
	private TransactionTestDao transactionTestDao;
	
	/**
	 * 在同一事务有多个数据源
	 */
	@Override
	@Transactional
	public void updateMultipleDataSource(String deUserId, String inUserid, long money,String str) {
		// 账户1转出操作
		mysqlTransactionTestDao.decreaseMoney(deUserId, money);
    Integer.parseInt("skg");
		// 账户2转入操作
		transactionTestDao.increaseMoney(inUserid, money);
		
	}	

}