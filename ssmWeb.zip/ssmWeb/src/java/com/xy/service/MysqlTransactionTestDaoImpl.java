package com.xy.service;

import com.xy.dao.MysqlTransactionTestDao;
import com.xy.dao.TransactionTestDao;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;

@Repository
public class MysqlTransactionTestDaoImpl extends SqlSessionDaoSupport implements MysqlTransactionTestDao {
   // 1，重写父类 【SqlSessionDaoSupport】方法实现注入【SqlSessionFactory】。
	// 2，必须要有，在配置文件【applicationContext.xml】要配置过。
	@Resource
	public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
		super.setSqlSessionFactory(sqlSessionFactory);
	}

	/**
	 * 转出操作
	 * @param userId    转出账号
	 * @param moneyNm   交易金额
	 */
	@Override
	public void decreaseMoney(@Param("userId") String userId, @Param("moneyNm") Long moneyNm) {
		// 参数设定
		MysqlTransactionTestDao mapper = super.getSqlSession().getMapper(MysqlTransactionTestDao.class);
		mapper.decreaseMoney(userId, moneyNm);
	}
}