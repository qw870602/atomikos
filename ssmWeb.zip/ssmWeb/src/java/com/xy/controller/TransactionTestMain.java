package com.xy.controller;

import com.xy.daodev.TransactionTestService;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;




@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
public class TransactionTestMain extends AbstractJUnit4SpringContextTests {
   @Autowired
	private TransactionTestService transactionTestService;
	
	/**
	 * 在同一事务有多个数据源
	 */
	@Test
	public void multipleDataSource2() {
		transactionTestService.updateMultipleDataSource("1","1", 100L,"1.6");
	}
}