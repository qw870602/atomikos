package com.xy.dao;

import org.springframework.stereotype.Repository;


public interface MysqlTransactionTestDao {

   public void decreaseMoney(String userId, Long money);

}