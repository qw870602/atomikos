package com.xy.dao;

import org.springframework.stereotype.Repository;


public interface TransactionTestDao {

   public void increaseMoney(String userId, Long moneyNm);


}