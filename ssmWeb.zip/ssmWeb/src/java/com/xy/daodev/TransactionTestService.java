package com.xy.daodev;

public interface TransactionTestService {

   /**
	 * 转账操作
	 * @param deUserId  转出账号
	 * @param inUserid  装入账号
	 * @param money     交易金额
	 */
	public void updateMultipleDataSource(String deUserId, String inUserid, long money,String str);
}