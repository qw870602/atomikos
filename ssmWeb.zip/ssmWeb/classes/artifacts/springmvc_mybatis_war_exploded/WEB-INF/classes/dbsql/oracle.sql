-- Create table
create table NAMEQA
(
  ID     VARCHAR2(50) default sys_guid(),
  NAMEQA VARCHAR2(50)
)
tablespace OMS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64
    next 8
    minextents 1
    maxextents unlimited
  );
-- Add comments to the table 
comment on table NAMEQA
  is '测试数据';
-- Add comments to the columns 
comment on column NAMEQA.ID
  is 'ID';
  
  
  
-----------------------------------------------------------------


-- Create table
create table NAMEDEV
(
  ID      VARCHAR2(50) default sys_guid(),
  NAMEDEV VARCHAR2(50)
)
tablespace COM
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64
    next 8
    minextents 1
    maxextents unlimited
  );