CREATE DATABASE /*!32312 IF NOT EXISTS*/`ssm_dev` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `ssm_dev`;

/*Table structure for table `namedev` */

DROP TABLE IF EXISTS `namedev`;

CREATE TABLE `namedev` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nameDev` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;


----------------------------------------------------------------------


CREATE DATABASE /*!32312 IF NOT EXISTS*/`ssm_qa` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `ssm_qa`;

/*Table structure for table `nameqa` */

DROP TABLE IF EXISTS `nameqa`;

CREATE TABLE `nameqa` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nameQa` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;